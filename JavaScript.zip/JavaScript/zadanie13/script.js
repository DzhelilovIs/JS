"use strict";
let num = 123;
alert(num);