"use strict";
let a = 1 + 2 + 3;
alert(a);