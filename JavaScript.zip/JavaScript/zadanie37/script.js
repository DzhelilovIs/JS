"use strict";
let str1 = "abcd";
let str2 = "qwerty";
let str = str1 * str2;

alert(str);