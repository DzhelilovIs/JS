"use strict";
let a = 10;
let b = 2;

let h = a + b;
let j = a - b;
let k = a * b;
let l = a / b;

alert(h);
alert(j);
alert(k);
alert(l);

let c = 10;
let d = 5;

let result = c + d;
alert(result);