"use strict";
const Pi = 3.14;
let r = 4;
let a = 2 * Pi * r;
alert(a);