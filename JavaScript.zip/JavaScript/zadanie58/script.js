"use strict";
let num = 47;
num += 7;
num -= 18;
num *= 10;
num /= 15;
alert(num);