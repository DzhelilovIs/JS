"use strict";
alert(10 / 0);
alert(-10 / 0);