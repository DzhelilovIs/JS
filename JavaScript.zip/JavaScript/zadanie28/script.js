"use strict";
let str1 = "Refat";
let str2 = "Bilyalov";
alert(str1 + " " + str2);