"use strict";
let a = 2;
let b = 10;

alert(a ** b);