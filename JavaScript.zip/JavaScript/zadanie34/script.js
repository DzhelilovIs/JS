"use strict";
let b;
alert(b);