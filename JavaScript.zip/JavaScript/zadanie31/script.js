"use strict";
let str1 = 'xxx';
let str2 = 'yyy';

let txt = `aaa ${str1} bbb ${str2} ccc`
alert(txt);