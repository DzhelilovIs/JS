"use strict";
let str1 = 'abcde';
alert(str1[str1.length - 1]);

let str2 = 'abcde';
alert(str2[str2.length - 2]);

let str3 = 'abcde';
alert(str3[str3.length - 3]);