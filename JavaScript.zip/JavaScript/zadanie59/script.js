"use strict";
let num = 10;
num++;
num++;
num--;
alert(num);