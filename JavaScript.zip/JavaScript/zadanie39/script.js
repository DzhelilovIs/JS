"use strict";
let a = 123;
console.log(a);

let b = 54;
let c = 2;
let d = 44;
console.log(b, c, d);