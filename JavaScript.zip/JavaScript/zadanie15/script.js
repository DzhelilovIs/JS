"use strict";
let a;

a = 10;
alert(a);

a = 20;
alert(a);