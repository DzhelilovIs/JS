"use strict";
let a = true;
alert(a);

let b = false;
alert(b);