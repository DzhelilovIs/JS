"use strict";
let num1 = parseFloat('5px');
let num2 = parseFloat('6px');
alert(num1 * num2 + "px");

let num3 = parseFloat('5.5px');
let num4 = parseFloat('6.25px');
alert(num3 * num4 + "px");