"use strict";
alert(eee); 