"use strict";
alert('text!');