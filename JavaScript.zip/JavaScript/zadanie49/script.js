"use strict";
let num1 = 123456;
alert(String(num1).length);

let num2 = 35343;
let num3 = 435343;
let str1 = String(num2);
let str2 = String(num3);
let str = str1 + str2;
alert(str.length);