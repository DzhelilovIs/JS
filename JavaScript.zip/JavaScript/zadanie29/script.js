"use strict";
let str = "!!!";
alert(str);

let java = "Java";
let script = "Script";
alert(java + script);

let hello = "Hello";
let world = "world";
alert(hello + " " + world);