"use strict";
let a = Number('2'); 
let b = Number('3'); 
alert(a + b);

/*
Задание 2: 5
Задание 3: 5 
Задание 4: 23
 */