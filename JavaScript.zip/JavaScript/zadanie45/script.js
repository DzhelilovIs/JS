"use strict";

let a = +'2';
let b = +'3';
alert(a + b); // выведет '23'