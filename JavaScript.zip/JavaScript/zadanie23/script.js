"use strict";
let a = -100;
alert(a);

let b = 12;
alert(-b);