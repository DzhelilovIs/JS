"use strict";
let test = '12345';
alert(Number(test[0]) + Number(test[1]) + Number(test[2]) + Number(test[3]) + Number(test[4]));

let test2 = '12345';
alert(Number(test2[0]) * Number(test2[1]) * Number(test2[2]) * Number(test2[3]) * Number(test2[4]));

let test3 = '12345';
alert(test3[4] + test3[3] + test3[2] + test3[1] + test3[0]);