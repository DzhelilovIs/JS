"use strict";
let str1 = 'abcde';
alert(str1[0]);
alert(str1[2]);
alert(str1[4]);

let str2 = 'abcde';
alert(str2[4] + str2[3] + str2[2] + str2[1] + str2[0]);

let str3 = 'abcde';
let num = 3;
alert(str3[num]);