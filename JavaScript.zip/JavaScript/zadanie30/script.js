"use strict";
let a = 'abcdefgh';
alert(a.length);