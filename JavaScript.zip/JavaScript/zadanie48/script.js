"use strict";
let a = 1;
let b = 2;

alert(String(a) + String(b));