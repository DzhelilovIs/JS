"use strict";
let str = `a
b
c`;
alert(str);