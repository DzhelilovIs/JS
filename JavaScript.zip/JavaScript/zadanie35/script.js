"use strict";
let b = null;
alert(b);