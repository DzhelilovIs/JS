"use strict";
let a = 10;
let b = 5;

let c = a - b;
 
let d = 7;

let result = c + d;
alert(result);