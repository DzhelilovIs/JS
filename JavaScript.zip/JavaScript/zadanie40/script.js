"use strict";
console.log(232);
console.log('232');