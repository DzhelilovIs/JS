"use strict";

let a = 1.5;
let b = 0.75;
let result = a + b;
alert(result);